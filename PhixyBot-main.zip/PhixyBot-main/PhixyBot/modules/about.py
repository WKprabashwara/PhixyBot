__help__ = """
** Phixy - A Powerful Telegram Group Manager 🧚 **

**Powerful Abilities:**
• Group Voice Chat Music Play ❤️
• File To Link and URL Upload 📂
• Youtube Downloader 🎵
• Powerful ChatBot 🧠

Developers [TeamPhixy 🇱🇰](https://t.me/TeamPhixy)
"""
__mod_name__ = "Aʙᴏᴜᴛ"
