__help__ = """
*Chatbot :*
Phixy AI 1.0 IS THE ONLY AI SYSTEM WHICH CAN DETECT & REPLY UPTO 200 LANGUAGES
〄 /chatbot [`ON/OFF`]: Enables and disables AI Chat mode (EXCLUSIVE)
〄 /chatbot EN : Enables English only chatbot
 
 
 *Assistant*
〄 /ask [question]: Ask question from daisy
〄 /ask [reply to voice note]: Get voice reply
 

"""

__mod_name__ = "Aɪ Aꜱꜱɪꜱᴛᴀɴᴛ"
