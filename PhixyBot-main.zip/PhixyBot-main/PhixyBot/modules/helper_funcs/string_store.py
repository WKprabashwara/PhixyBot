PHIXY = [
    "Yeah Babe Tell me.",
    "Something went wrong.",
    "Something went wrong.",
    "Something went wrong.",
    "Something went wrong.",
    "Something went wrong.",
    "Nope",
    "Maybe",
    "Nope",
    "Something went wrong.",
    "Something went wrong.",
    "Nope",
    "Nope",
    "Nope",
    "Nope",
    "Something went wrong.",
    "Maybe",
    "Something went wrong.",
    "Nope",
    "Something went wrong",
    "Maybe",
    "Something went wrong",
    "Something went wrong",
    "Something went wrong",
    "Something went wrong",
    "Nope",
    "Nope",
    "Maybe",
    "Nope",
    "Something went wrong",
    "Something went wrong",
    "Something went wrong",
    "Something went wrong",
    "Nope",
    "Something went wrong",
    "Maybe",
    "Nope",
]

GDMORNING = [
    "Good Morning Babe 🥱⛅️🌈",
]

GDNIGHT = [
    "Good Night Babe ☺️🌒✨",
]

PRABASHWARA = [
    "Oh! 🤯",
]
