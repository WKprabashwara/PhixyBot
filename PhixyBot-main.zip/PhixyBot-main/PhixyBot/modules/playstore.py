
__mod_name__ = "Aᴘᴘꜱ"

__help__ = """
*Playsrore App Searching*

 〄 /app  :  `/app Telegram` To Get Telegram 
"""
